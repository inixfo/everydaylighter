EverydayLighter checkout/live fixes

1) Checkout shows Sign in/Create account while preserving exact checkout URL.
2) Emailed guest access links work with order + guest_access_token and no Stripe session_id.

Apply from repository root:
  unzip -o EverydayLighter_Live_Checkout_Fixes.zip -d /tmp/everydaylighter-fixes
  cp -a /tmp/everydaylighter-fixes/design/project/src/pages/checkout/Checkout.tsx design/project/src/pages/checkout/Checkout.tsx
  cp -a /tmp/everydaylighter-fixes/design/project/src/pages/checkout/PurchaseSuccess.tsx design/project/src/pages/checkout/PurchaseSuccess.tsx
  git diff
  docker compose build web
  docker compose up -d web
